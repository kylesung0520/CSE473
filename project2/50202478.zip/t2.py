# 1. Only add your code inside the function (including newly improted packages). 
#  You can design a new function and call the new function in the given functions. 
# 2. For bonus: Give your own picturs. If you have N pictures, name your pictures such as ["t3_1.png", "t3_2.png", ..., "t3_N.png"], and put them inside the folder "images".
# 3. Not following the project guidelines will result in a 10% reduction in grades
import json

import cv2
import numpy as np
import matplotlib.pyplot as plt

def extractor(key_points, features, descriptor, imgs):
    for img in imgs:
        key_point, feature = descriptor.detectAndCompute(img, None)
        key_points.append(key_point)
        features.append(feature)
    return key_points, features
def stitch(imgmark, N=4, savepath=''): #For bonus: change your input(N=*) here as default if the number of your input pictures is not 4.
    "The output image should be saved in the savepath."
    "The intermediate overlap relation should be returned as NxN a one-hot(only contains 0 or 1) array."
    "Do NOT modify the code provided."
    imgpath = [f'./images/{imgmark}_{n}.png' for n in range(1,N+1)]
    imgs = []
    for ipath in imgpath:
        img = cv2.imread(ipath)
        imgs.append(img)

    "Start you code here"
    tmp_imgs = []
    for img in imgs:
        tmp_imgs.append(cv2.cvtColor(img, cv2.COLOR_RGB2GRAY))

    descriptor = cv2.SIFT_create()
    key_points, features = extractor([], [], descriptor, tmp_imgs)

    return overlap_arr

if __name__ == "__main__":
    #task2
    overlap_arr = stitch('t2', N=4, savepath='task2.png')
    with open('t2_overlap.txt', 'w') as outfile:
        json.dump(overlap_arr.tolist(), outfile)
    #bonus
    overlap_arr2 = stitch('t3', savepath='task3.png')
    with open('t3_overlap.txt', 'w') as outfile:
        json.dump(overlap_arr2.tolist(), outfile)
